//
//  ViewController.swift
//  converrancy
//
//  Created by Lamia Turki on 27/03/1442 AH.
//

import UIKit

class ViewController: UIViewController {
    enum convertError: Error {
        case incompleteForm
        case invalidFeild
        case incorrecrLength
        case incorrectValue
        case incorrectFormat
      
        
    }

    var amountValue="0.0"
    
    @IBOutlet weak var ConverrancyLable: UILabel!
    
    @IBOutlet weak var CurrencyLable: UILabel!
    
    @IBOutlet weak var ValueLable: UILabel!
    
    @IBOutlet weak var CurrencyTextfield: UITextField!
    
    @IBOutlet weak var ValueTextfield: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func ConverButton(_ sender: UIButton) {
        do {
            try convertValidation()
            
            let value : String = ValueTextfield.text!  
            let currency : String = CurrencyTextfield.text!

           
                if let actualNumber = Double(value) {
                    
                    let res:Double = convert(num: actualNumber , curn: currency.uppercased())
                if(res >= 0 ){
                    amountValue = String(format:"%.2f",res)
                    self.performSegue(withIdentifier: "goToResult", sender: self)
                    erase()
                        } else {
                            throw convertError.incorrectFormat
                            
                        }
                    
                } else {
                    throw convertError.incorrectFormat
                }
           
            
        }
        catch convertError.incompleteForm {
            let alertVC = UIAlertController(title: "incomplete form", message: "Please fill in both amount and currency", preferredStyle: .alert)
            let dismiss = UIAlertAction(title: "Dismiss", style: .default , handler: nil)
            
            alertVC.addAction(dismiss)
            self.present(alertVC, animated: true)
            
            erase()
        }
        
        
        catch convertError.incorrecrLength {
            let alertVC = UIAlertController(title: "incorrect length", message: "Amount should be less than 9 digits and currency should be less than 4 characters", preferredStyle: .alert)
            let dismiss = UIAlertAction(title: "Dismiss", style: .default , handler: nil)
            
            alertVC.addAction(dismiss)
            self.present(alertVC, animated: true)
            
            erase()

        }
        catch convertError.incorrectValue {
            let alertVC = UIAlertController(title: "inncorrect value", message: "Value should be greater than 0", preferredStyle: .alert)
            let dismiss = UIAlertAction(title: "Dismiss", style: .default , handler: nil)
            
            alertVC.addAction(dismiss)
            self.present(alertVC, animated: true)
            
            erase()
        }
        catch convertError.incorrectFormat {
            let alertVC = UIAlertController(title: "incorrect format", message: "Amount should be numerical value and currency should be one of the following: USD , YEN , EUR", preferredStyle: .alert)
             let dismiss = UIAlertAction(title: "Dismiss", style: .default , handler: nil)
             
             alertVC.addAction(dismiss)
             self.present(alertVC, animated: true)
            
            erase()

        }
        
        catch {
           let alertVC = UIAlertController(title: "Error", message: "", preferredStyle: .alert)
            let dismiss = UIAlertAction(title: "Dismiss", style: .default , handler: nil)
            
            alertVC.addAction(dismiss)
            self.present(alertVC, animated: true)
            
            erase()

        }
        
        
    }
    
    func convertValidation() throws {
        
        let amount : String = ValueTextfield.text!
        let currency : String = CurrencyTextfield.text!
        
        if amount.isEmpty || currency.isEmpty {
            throw convertError.incompleteForm
        }
        
        if amount.count > 8 {
            throw convertError.incorrecrLength
        }
        
        if currency.count > 3 {
            throw convertError.incorrecrLength
        }
        
        if let amountD  = Double(amount) {
            if  amountD <= 0 {
            throw convertError.incorrectValue
        }}
        else {

            throw convertError.incorrectFormat
            
        }
        if currency.uppercased() != "USD" && currency.uppercased() != "YEN" &&  currency.uppercased() != "EUR" && currency != "$" && currency != "￥" &&  currency != "€" {
            
        throw convertError.incorrectFormat
            
        }
        
    }
    
    func erase(){
        ValueTextfield.text = ""
        
        CurrencyTextfield.text = ""
            
    }
    
    func convert( num:Double , curn:String ) -> Double {
      
        switch curn {
            case "USD" , "$":
                return num*3.75
            case "YEN" , "￥":
                return num*0.036
            case "EUR" , "€":
                return num*4.43
            default:
                return -1
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToResult" {
            let destinationVC = segue.destination as! SecondViewController
            destinationVC.Result = amountValue
            
        }
    }
    
    
}

