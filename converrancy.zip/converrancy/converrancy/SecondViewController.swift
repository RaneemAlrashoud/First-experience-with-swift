//
//  SecondViewController.swift
//  converrancy
//
//  Created by Lamia Turki on 04/04/1442 AH.
//

import UIKit

class SecondViewController: UIViewController {

    var Result : String?
    
    @IBOutlet weak var ResultLable: UILabel!
    
    @IBOutlet weak var ResultValueLable: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ResultValueLable.text = Result
     
    }
    

    @IBAction func RecalculateButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
        
    }
    

}
